#!/bin/sh
set -e

Rscript src/run.R