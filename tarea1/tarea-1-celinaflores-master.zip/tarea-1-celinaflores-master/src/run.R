## 
## Scripts a ejecutar
## usar el comando source y el script a ejecutar
## Más info ?source

source("src/tarea.R")